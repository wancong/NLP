from flask import jsonify, render_template, request

from js_example import app

from pyhanlp import *
import jpype

import json


@app.route('/', defaults={'js': 'plain'})
@app.route('/<any(plain, jquery, fetch):js>')
#@app.route('/')
#def index(js):
def index(js):
    return render_template('{0}.html'.format(js), js=js)
    #return render_template('plain.html')


@app.route('/add', methods=['POST'])
def add():
    text = request.form.get('a', " ", type=str)

    if not jpype.isThreadAttachedToJVM():
        jpype.attachThreadToJVM()
    NLPTokenizer = jpype.JClass("com.hankcs.hanlp.tokenizer.NLPTokenizer")
    TextRankKeyword = jpype.JClass("com.hankcs.hanlp.summary.TextRankKeyword")
    NotionalTokenizer = jpype.JClass("com.hankcs.hanlp.tokenizer.NotionalTokenizer")
    TextRankSentence = jpype.JClass("com.hankcs.hanlp.summary.TextRankSentence")

    return jsonify(result=(NLPTokenizer.segment(text)).toString(),
        keyword=HanLP.extractKeyword(text, 5).toString(),
        phrase_extractor=HanLP.extractPhrase(text, 5).toString(),
        summary=HanLP.extractSummary(text, 1).toString()
    )

@app.route('/add1', methods=['POST'])
def add1():
    text = request.form.get('a', " ", type=str)

    if not jpype.isThreadAttachedToJVM():
        jpype.attachThreadToJVM()
    sentence = HanLP.parseDependency(text)
    CoreSynonymDictionary = JClass("com.hankcs.hanlp.dictionary.CoreSynonymDictionary")

    dependency_parser = []
    for word in sentence.iterator():  # 通过dir()可以查看sentence的方法
        dependency_parser.append("%s --(%s)--> %s\n" % (word.LEMMA, word.DEPREL, word.HEAD.LEMMA))

    return jsonify(dependency_parser=dependency_parser,
        rewrite_text=CoreSynonymDictionary.rewrite(text)
        )

@app.route('/add2', methods=['POST'])
def add2():
    text = request.form.get('a', " ", type=str)
    title_array = text.split(';')

    if not jpype.isThreadAttachedToJVM():
        jpype.attachThreadToJVM()
    Suggester = JClass("com.hankcs.hanlp.suggest.Suggester")
    suggester = Suggester()
    for title in title_array:
        suggester.addSentence(title)

    return jsonify(suggester1=suggester.suggest("陈述", 2).toString(),
        suggester2=suggester.suggest("危机公关", 2).toString(),
        suggester3=suggester.suggest("mayun", 2).toString()
        )
